common='b554e7a2388d77b2ade747edd2cc504d';
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC-mTD-ZMu-KvDnuuky2HvJrszFFPNjAy4",
  authDomain: "webpow.firebaseapp.com",
  databaseURL: "https://webpow.firebaseio.com",
  projectId: "webpow",
  storageBucket: "webpow.appspot.com",
  messagingSenderId: "926240433968",
  appId: "1:926240433968:web:bc67306ec2c15766778af5",
  measurementId: "G-D5VYBNF06K"
};